import os
import uuid
import stripe
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

load_dotenv()

from app.database import get_connection, init_db
from app.auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_admin,
)

app = FastAPI(title="Repellix API")

# Disable CORS. Do not remove this for full-stack development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:5173")

# Setup uploads directory
DB_DIR = os.environ.get("DB_DIR", "/data")
UPLOADS_DIR = os.path.join(DB_DIR, "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

# Serve uploaded images as static files
app.mount("/uploads", StaticFiles(directory=UPLOADS_DIR), name="uploads")


# --- Pydantic Models ---

class AdminLogin(BaseModel):
    username: str
    password: str

class AdminCreate(BaseModel):
    username: str
    password: str

class ProductCreate(BaseModel):
    name: str
    description: str = ""
    price: float
    original_price: Optional[float] = None
    image_url: str = ""
    category: str = ""
    rating: float = 0
    reviews_count: int = 0
    badge: str = ""
    in_stock: bool = True

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    original_price: Optional[float] = None
    image_url: Optional[str] = None
    category: Optional[str] = None
    rating: Optional[float] = None
    reviews_count: Optional[int] = None
    badge: Optional[str] = None
    in_stock: Optional[bool] = None

class CheckoutItem(BaseModel):
    product_id: int
    quantity: int

class CheckoutRequest(BaseModel):
    items: list[CheckoutItem]
    customer_email: str
    customer_name: str = ""
    shipping_address: str = ""
    payment_method: str = "stripe"

class CODCheckoutRequest(BaseModel):
    items: list[CheckoutItem]
    customer_email: str
    customer_name: str = ""
    shipping_address: str = ""
    payment_method: str = "cod"

class OrderStatusUpdate(BaseModel):
    status: str

class PasswordChange(BaseModel):
    current_password: str
    new_password: str


# --- Startup ---

@app.on_event("startup")
def on_startup():
    init_db()
    # Create or reset default admin
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM admin_users")
    row = cursor.fetchone()
    if row["cnt"] == 0:
        hashed = hash_password("admin123")
        cursor.execute("INSERT INTO admin_users (username, hashed_password) VALUES (?, ?)", ("admin", hashed))
        conn.commit()
    else:
        # Reset admin password on every startup to ensure it always works
        hashed = hash_password("admin123")
        cursor.execute("UPDATE admin_users SET hashed_password = ? WHERE username = ?", (hashed, "admin"))
        conn.commit()
    conn.close()


@app.get("/healthz")
async def healthz():
    return {"status": "ok"}


# --- Auth ---

@app.post("/api/admin/login")
async def admin_login(data: AdminLogin):
    username = data.username.strip()
    password = data.password.strip()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM admin_users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()
    if not user or not verify_password(password, user["hashed_password"]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_access_token({"sub": user["username"]})
    return {"access_token": token, "token_type": "bearer"}


@app.put("/api/admin/change-password")
async def change_password(data: PasswordChange, admin_user: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM admin_users WHERE username = ?", (admin_user,))
    user = cursor.fetchone()
    if not user or not verify_password(data.current_password.strip(), user["hashed_password"]):
        conn.close()
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    new_pw = data.new_password.strip()
    if len(new_pw) < 6:
        conn.close()
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters")
    hashed = hash_password(new_pw)
    cursor.execute("UPDATE admin_users SET hashed_password = ? WHERE username = ?", (hashed, admin_user))
    conn.commit()
    conn.close()
    return {"message": "Password changed successfully"}


@app.post("/api/admin/register")
async def admin_register(data: AdminCreate, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM admin_users WHERE username = ?", (data.username,))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Username already exists")
    hashed = hash_password(data.password)
    cursor.execute("INSERT INTO admin_users (username, hashed_password) VALUES (?, ?)", (data.username, hashed))
    conn.commit()
    conn.close()
    return {"message": "Admin user created"}


# --- Products (Public) ---

@app.get("/api/products")
async def list_products(category: Optional[str] = None, search: Optional[str] = None):
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM products WHERE 1=1"
    params: list = []
    if category and category != "All":
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND name LIKE ?"
        params.append(f"%{search}%")
    query += " ORDER BY created_at DESC"
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


@app.get("/api/products/{product_id}")
async def get_product(product_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Product not found")
    return dict(row)


@app.get("/api/categories")
async def list_categories():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT category FROM products WHERE category != '' ORDER BY category")
    rows = cursor.fetchall()
    conn.close()
    return [row["category"] for row in rows]


# --- Image Upload (Admin) ---

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

@app.post("/api/admin/upload-image")
async def upload_image(file: UploadFile = File(...), _admin: str = Depends(get_current_admin)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"File type {ext} not allowed. Use: {', '.join(ALLOWED_EXTENSIONS)}")
    contents = await file.read()
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="File too large. Max 5MB.")
    filename = f"{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOADS_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(contents)
    image_url = f"/uploads/{filename}"
    return {"image_url": image_url, "filename": filename}


# --- Products (Admin) ---

@app.post("/api/admin/products")
async def create_product(product: ProductCreate, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO products (name, description, price, original_price, image_url, category, rating, reviews_count, badge, in_stock)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (product.name, product.description, product.price, product.original_price,
         product.image_url, product.category, product.rating, product.reviews_count,
         product.badge, 1 if product.in_stock else 0)
    )
    conn.commit()
    product_id = cursor.lastrowid
    conn.close()
    return {"id": product_id, "message": "Product created"}


@app.put("/api/admin/products/{product_id}")
async def update_product(product_id: int, product: ProductUpdate, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM products WHERE id = ?", (product_id,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Product not found")

    updates = []
    params: list = []
    data = product.model_dump(exclude_none=True)
    if "in_stock" in data:
        data["in_stock"] = 1 if data["in_stock"] else 0
    for key, value in data.items():
        updates.append(f"{key} = ?")
        params.append(value)
    if updates:
        updates.append("updated_at = CURRENT_TIMESTAMP")
        params.append(product_id)
        cursor.execute(f"UPDATE products SET {', '.join(updates)} WHERE id = ?", params)
        conn.commit()
    conn.close()
    return {"message": "Product updated"}


@app.delete("/api/admin/products/{product_id}")
async def delete_product(product_id: int, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
    conn.commit()
    conn.close()
    return {"message": "Product deleted"}


# --- Checkout / Stripe ---

@app.post("/api/checkout")
async def create_checkout(data: CheckoutRequest):
    if not stripe.api_key:
        raise HTTPException(status_code=500, detail="Stripe is not configured. Please set STRIPE_SECRET_KEY.")

    conn = get_connection()
    cursor = conn.cursor()

    line_items = []
    order_items_data = []
    total = 0.0

    for item in data.items:
        cursor.execute("SELECT * FROM products WHERE id = ?", (item.product_id,))
        product = cursor.fetchone()
        if not product:
            conn.close()
            raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")

        line_items.append({
            "price_data": {
                "currency": "usd",
                "product_data": {"name": product["name"]},
                "unit_amount": int(product["price"] * 100),
            },
            "quantity": item.quantity,
        })
        order_items_data.append({
            "product_id": product["id"],
            "product_name": product["name"],
            "quantity": item.quantity,
            "price": product["price"],
        })
        total += product["price"] * item.quantity

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=line_items,
            mode="payment",
            success_url=FRONTEND_URL + "?payment=success&session_id={CHECKOUT_SESSION_ID}",
            cancel_url=FRONTEND_URL + "?payment=cancelled",
            customer_email=data.customer_email,
        )
    except stripe.StripeError as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))

    cursor.execute(
        """INSERT INTO orders (customer_email, customer_name, shipping_address, status, total, stripe_session_id)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (data.customer_email, data.customer_name, data.shipping_address, "pending", total, session.id)
    )
    order_id = cursor.lastrowid

    for oi in order_items_data:
        cursor.execute(
            "INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?, ?, ?, ?, ?)",
            (order_id, oi["product_id"], oi["product_name"], oi["quantity"], oi["price"])
        )

    conn.commit()
    conn.close()

    return {"checkout_url": session.url, "session_id": session.id, "order_id": order_id}


@app.post("/api/checkout/verify")
async def verify_checkout(session_id: str):
    if not stripe.api_key:
        raise HTTPException(status_code=500, detail="Stripe not configured")
    try:
        session = stripe.checkout.Session.retrieve(session_id)
    except stripe.StripeError as e:
        raise HTTPException(status_code=400, detail=str(e))

    conn = get_connection()
    cursor = conn.cursor()
    if session.payment_status == "paid":
        cursor.execute(
            "UPDATE orders SET status = 'paid', stripe_payment_intent_id = ?, updated_at = CURRENT_TIMESTAMP WHERE stripe_session_id = ?",
            (session.payment_intent, session_id)
        )
        conn.commit()
    conn.close()
    return {"payment_status": session.payment_status}


# --- COD / UPI Checkout (India) ---

@app.post("/api/checkout/cod")
async def create_cod_checkout(data: CODCheckoutRequest):
    conn = get_connection()
    cursor = conn.cursor()

    order_items_data = []
    total = 0.0

    for item in data.items:
        cursor.execute("SELECT * FROM products WHERE id = ?", (item.product_id,))
        product = cursor.fetchone()
        if not product:
            conn.close()
            raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")

        order_items_data.append({
            "product_id": product["id"],
            "product_name": product["name"],
            "quantity": item.quantity,
            "price": product["price"],
        })
        total += product["price"] * item.quantity

    cursor.execute(
        """INSERT INTO orders (customer_email, customer_name, shipping_address, status, total, stripe_session_id)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (data.customer_email.strip().lower(), data.customer_name, data.shipping_address, "pending", total, f"{data.payment_method}_{uuid.uuid4().hex[:8]}")
    )
    order_id = cursor.lastrowid

    for oi in order_items_data:
        cursor.execute(
            "INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?, ?, ?, ?, ?)",
            (order_id, oi["product_id"], oi["product_name"], oi["quantity"], oi["price"])
        )

    conn.commit()
    conn.close()

    return {"order_id": order_id, "total": total, "payment_method": data.payment_method, "message": "Order placed successfully!"}


# --- Order Tracking (Customer) ---

@app.get("/api/orders/track")
async def track_orders(email: str):
    if not email or not email.strip():
        raise HTTPException(status_code=400, detail="Email is required")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders WHERE customer_email = ? ORDER BY created_at DESC", (email.strip().lower(),))
    orders = [dict(row) for row in cursor.fetchall()]
    for order in orders:
        cursor.execute("SELECT * FROM order_items WHERE order_id = ?", (order["id"],))
        order["items"] = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return orders


# --- Newsletter Subscribe ---

class SubscribeRequest(BaseModel):
    email: str

@app.post("/api/subscribe")
async def subscribe_newsletter(data: SubscribeRequest):
    if not data.email or not data.email.strip():
        raise HTTPException(status_code=400, detail="Email is required")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    try:
        cursor.execute("INSERT INTO subscribers (email) VALUES (?)", (data.email.strip().lower(),))
        conn.commit()
    except Exception:
        conn.close()
        return {"message": "You're already subscribed!"}
    conn.close()
    return {"message": "Subscribed successfully!"}


# --- Orders (Admin) ---

@app.get("/api/admin/orders")
async def list_orders(status_filter: Optional[str] = None, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM orders"
    params: list = []
    if status_filter:
        query += " WHERE status = ?"
        params.append(status_filter)
    query += " ORDER BY created_at DESC"
    cursor.execute(query, params)
    orders = [dict(row) for row in cursor.fetchall()]

    for order in orders:
        cursor.execute("SELECT * FROM order_items WHERE order_id = ?", (order["id"],))
        order["items"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return orders


@app.get("/api/admin/orders/{order_id}")
async def get_order(order_id: int, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        raise HTTPException(status_code=404, detail="Order not found")
    order = dict(order)
    cursor.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,))
    order["items"] = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return order


@app.put("/api/admin/orders/{order_id}/status")
async def update_order_status(order_id: int, data: OrderStatusUpdate, _admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM orders WHERE id = ?", (order_id,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Order not found")
    cursor.execute(
        "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (data.status, order_id)
    )
    conn.commit()
    conn.close()
    return {"message": "Order status updated"}


# --- Dashboard Stats (Admin) ---

@app.get("/api/admin/stats")
async def admin_stats(_admin: str = Depends(get_current_admin)):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) as cnt FROM products")
    total_products = cursor.fetchone()["cnt"]

    cursor.execute("SELECT COUNT(*) as cnt FROM orders")
    total_orders = cursor.fetchone()["cnt"]

    cursor.execute("SELECT COALESCE(SUM(total), 0) as rev FROM orders WHERE status = 'paid'")
    total_revenue = cursor.fetchone()["rev"]

    cursor.execute("SELECT COUNT(*) as cnt FROM orders WHERE status = 'pending'")
    pending_orders = cursor.fetchone()["cnt"]

    conn.close()
    return {
        "total_products": total_products,
        "total_orders": total_orders,
        "total_revenue": round(total_revenue, 2),
        "pending_orders": pending_orders,
    }
