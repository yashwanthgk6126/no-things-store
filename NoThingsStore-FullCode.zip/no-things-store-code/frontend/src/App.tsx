import { useState, useEffect, useCallback } from 'react'
import './App.css'
import { ShoppingCart, Star, Search, Menu, X, Plus, Minus, Trash2, ArrowRight, Zap, Truck, Shield, Heart, LogIn, LogOut, Package, DollarSign, BarChart3, Edit, Save, Eye, Settings, Lock, Upload, Phone, MessageCircle } from 'lucide-react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'

interface Product {
  id: number
  name: string
  description: string
  price: number
  original_price: number | null
  image_url: string
  category: string
  rating: number
  reviews_count: number
  badge: string
  in_stock: number
}

interface CartItem extends Product {
  quantity: number
}

interface Order {
  id: number
  customer_email: string
  customer_name: string
  shipping_address: string
  status: string
  total: number
  created_at: string
  items: { product_name: string; quantity: number; price: number }[]
}

interface Stats {
  total_products: number
  total_orders: number
  total_revenue: number
  pending_orders: number
}

type Page = 'store' | 'admin' | 'track'

function App() {
  const [page, setPage] = useState<Page>('store')
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [wishlist, setWishlist] = useState<number[]>([])
  const [trackEmail, setTrackEmail] = useState('')
  const [trackedOrders, setTrackedOrders] = useState<Order[]>([])
  const [trackMsg, setTrackMsg] = useState('')
  const [trackLoading, setTrackLoading] = useState(false)
  const [subscribeEmail, setSubscribeEmail] = useState('')
  const [subscribeMsg, setSubscribeMsg] = useState('')
  const [checkoutEmail, setCheckoutEmail] = useState("")
  const [checkoutName, setCheckoutName] = useState("")
  const [checkoutAddress, setCheckoutAddress] = useState("")
  const [showCheckoutForm, setShowCheckoutForm] = useState(false)
  const [checkoutLoading, setCheckoutLoading] = useState(false)
  const [checkoutError, setCheckoutError] = useState("")

  const [token, setToken] = useState(localStorage.getItem('admin_token') || '')
  const [loginUser, setLoginUser] = useState('')
  const [loginPass, setLoginPass] = useState('')
  const [loginError, setLoginError] = useState('')
  const [adminTab, setAdminTab] = useState<'stats' | 'products' | 'orders' | 'settings'>('stats')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordMsg, setPasswordMsg] = useState('')
  const [passwordMsgType, setPasswordMsgType] = useState<'success' | 'error'>('error')
  const [stats, setStats] = useState<Stats | null>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [editProduct, setEditProduct] = useState<Partial<Product> | null>(null)
  const [productFormMsg, setProductFormMsg] = useState('')
  const [productFormMsgType, setProductFormMsgType] = useState<'success' | 'error' | 'info'>('info')
  const [uploading, setUploading] = useState(false)

  const isAdmin = !!token

  const fetchProducts = useCallback(async () => {
    try {
      const params = new URLSearchParams()
      if (selectedCategory !== 'All') params.set('category', selectedCategory)
      if (searchQuery) params.set('search', searchQuery)
      const res = await fetch(`${API}/api/products?${params}`)
      const data = await res.json()
      setProducts(data)
    } catch { /* empty */ }
  }, [selectedCategory, searchQuery])

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch(`${API}/api/categories`)
      const data = await res.json()
      setCategories(['All', ...data])
    } catch { /* empty */ }
  }, [])

  useEffect(() => { fetchProducts() }, [fetchProducts])
  useEffect(() => { fetchCategories() }, [fetchCategories])

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('payment') === 'success') {
      setCart([])
      window.history.replaceState({}, '', window.location.pathname)
    }
  }, [])

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id)
      if (existing) {
        return prev.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      }
      return [...prev, { ...product, quantity: 1 }]
    })
  }

  const updateQuantity = (id: number, delta: number) => {
    setCart(prev =>
      prev.map(item => item.id === id ? { ...item, quantity: item.quantity + delta } : item)
        .filter(item => item.quantity > 0)
    )
  }

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id))
  }

  const toggleWishlist = (id: number) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)
  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const handleCheckout = async (paymentMethod: string) => {
    if (!checkoutEmail) { setCheckoutError('Email is required'); return }
    if (!checkoutName) { setCheckoutError('Name is required'); return }
    if (!checkoutAddress) { setCheckoutError('Shipping address is required'); return }
    setCheckoutLoading(true)
    setCheckoutError('')
    try {
      const res = await fetch(`${API}/api/checkout/cod`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map(item => ({ product_id: item.id, quantity: item.quantity })),
          customer_email: checkoutEmail,
          customer_name: checkoutName,
          shipping_address: checkoutAddress,
          payment_method: paymentMethod,
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        setCheckoutError(data.detail || 'Order failed. Please try again.')
        setCheckoutLoading(false)
        return
      }
      setCart([])
      setShowCheckoutForm(false)
      setIsCartOpen(false)
      setCheckoutEmail('')
      setCheckoutName('')
      setCheckoutAddress('')
      alert(`Order placed successfully! Order #${data.order_id}\nTotal: ₹${data.total.toFixed(2)}\nPayment: ${paymentMethod === 'cod' ? 'Cash on Delivery' : 'UPI'}\n\nYou can track your order using your email.`)
    } catch {
      setCheckoutError('Network error. Please try again.')
    }
    setCheckoutLoading(false)
  }

  const handleLogin = async () => {
    setLoginError('')
    const u = loginUser.trim()
    const p = loginPass.trim()
    if (!u || !p) { setLoginError('Please enter username and password'); return }
    try {
      const res = await fetch(`${API}/api/admin/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: u, password: p }),
      })
      const data = await res.json()
      if (!res.ok) { setLoginError(data.detail || 'Login failed'); return }
      setToken(data.access_token)
      localStorage.setItem('admin_token', data.access_token)
      setLoginUser('')
      setLoginPass('')
    } catch { setLoginError('Network error. Please try again.') }
  }

  const handleLogout = () => {
    setToken('')
    localStorage.removeItem('admin_token')
    setPage('store')
  }

  const fetchStats = useCallback(async () => {
    if (!token) return
    try {
      const res = await fetch(`${API}/api/admin/stats`, { headers: { Authorization: `Bearer ${token}` } })
      if (res.ok) setStats(await res.json())
      else if (res.status === 401) handleLogout()
    } catch { /* empty */ }
  }, [token])

  const fetchOrders = useCallback(async () => {
    if (!token) return
    try {
      const res = await fetch(`${API}/api/admin/orders`, { headers: { Authorization: `Bearer ${token}` } })
      if (res.ok) setOrders(await res.json())
    } catch { /* empty */ }
  }, [token])

  useEffect(() => {
    if (page === 'admin' && isAdmin) {
      fetchStats()
      fetchOrders()
    }
  }, [page, isAdmin, fetchStats, fetchOrders])

  const saveProduct = async () => {
    if (!editProduct || !editProduct.name || !editProduct.price) {
      setProductFormMsg('Name and price are required')
      return
    }
    setProductFormMsg('')
    const isNew = !editProduct.id
    const url = isNew ? `${API}/api/admin/products` : `${API}/api/admin/products/${editProduct.id}`
    const method = isNew ? 'POST' : 'PUT'
    try {
      const body: Record<string, unknown> = {
        name: editProduct.name,
        description: editProduct.description || '',
        price: editProduct.price,
        original_price: editProduct.original_price || null,
        image_url: editProduct.image_url || '',
        category: editProduct.category || '',
        rating: editProduct.rating || 0,
        reviews_count: editProduct.reviews_count || 0,
        badge: editProduct.badge || '',
        in_stock: editProduct.in_stock !== undefined ? !!editProduct.in_stock : true,
      }
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      })
      if (res.ok) {
        setProductFormMsg(isNew ? 'Product created!' : 'Product updated!')
        setEditProduct(null)
        fetchProducts()
        fetchStats()
      } else {
        const data = await res.json()
        setProductFormMsg(data.detail || 'Error saving product')
      }
    } catch { setProductFormMsg('Network error') }
  }

  const handleImageUpload = async (file: File) => {
    setUploading(true)
    setProductFormMsg('Uploading image...')
    setProductFormMsgType('info')
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch(`${API}/api/admin/upload-image`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })
      const data = await res.json()
      if (res.ok) {
        const fullUrl = `${API}${data.image_url}`
        setEditProduct(prev => prev ? { ...prev, image_url: fullUrl } : prev)
        setProductFormMsg('Image uploaded successfully! You can now save the product.')
        setProductFormMsgType('success')
      } else {
        setProductFormMsg(data.detail || 'Upload failed')
        setProductFormMsgType('error')
      }
    } catch {
      setProductFormMsg('Upload failed. Please try again.')
      setProductFormMsgType('error')
    }
    setUploading(false)
  }

  const deleteProduct = async (id: number) => {
    try {
      await fetch(`${API}/api/admin/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      })
      fetchProducts()
      fetchStats()
    } catch { /* empty */ }
  }

  const handleChangePassword = async () => {
    setPasswordMsg('')
    if (!currentPassword || !newPassword) { setPasswordMsg('Please fill in all fields'); setPasswordMsgType('error'); return }
    if (newPassword.length < 6) { setPasswordMsg('New password must be at least 6 characters'); setPasswordMsgType('error'); return }
    if (newPassword !== confirmPassword) { setPasswordMsg('New passwords do not match'); setPasswordMsgType('error'); return }
    try {
      const res = await fetch(`${API}/api/admin/change-password`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
      })
      const data = await res.json()
      if (res.ok) {
        setPasswordMsg('Password changed successfully!')
        setPasswordMsgType('success')
        setCurrentPassword('')
        setNewPassword('')
        setConfirmPassword('')
      } else {
        setPasswordMsg(data.detail || 'Failed to change password')
        setPasswordMsgType('error')
      }
    } catch { setPasswordMsg('Network error'); setPasswordMsgType('error') }
  }

  const updateOrderStatus = async (orderId: number, status: string) => {
    try {
      await fetch(`${API}/api/admin/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status }),
      })
      fetchOrders()
      fetchStats()
    } catch { /* empty */ }
  }

  const imgFallback = "https://placehold.co/600x600/1a1a2e/e94560?text=Product"

  const handleTrackOrders = async () => {
    if (!trackEmail.trim()) { setTrackMsg('Please enter your email'); return }
    setTrackLoading(true)
    setTrackMsg('')
    try {
      const res = await fetch(`${API}/api/orders/track?email=${encodeURIComponent(trackEmail.trim())}`)
      const data = await res.json()
      if (res.ok) {
        setTrackedOrders(data)
        if (data.length === 0) setTrackMsg('No orders found for this email address.')
      } else {
        setTrackMsg(data.detail || 'Error tracking orders')
      }
    } catch { setTrackMsg('Network error. Please try again.') }
    setTrackLoading(false)
  }

  const handleSubscribe = async () => {
    if (!subscribeEmail.trim()) { setSubscribeMsg('Please enter your email'); return }
    try {
      const res = await fetch(`${API}/api/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: subscribeEmail.trim() }),
      })
      const data = await res.json()
      setSubscribeMsg(data.message || 'Subscribed!')
      if (res.ok) setSubscribeEmail('')
    } catch { setSubscribeMsg('Network error. Please try again.') }
  }

  const statusColor = (s: string) => {
    switch (s) {
      case 'paid': return 'bg-green-500/20 text-green-400'
      case 'shipped': return 'bg-blue-500/20 text-blue-400'
      case 'delivered': return 'bg-emerald-500/20 text-emerald-400'
      default: return 'bg-yellow-500/20 text-yellow-400'
    }
  }

  if (page === 'admin') {
    if (!isAdmin) {
      return (
        <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
          <div className="w-full max-w-sm bg-gray-900 border border-gray-800 rounded-2xl p-8">
            <div className="flex items-center gap-2 mb-6 justify-center">
              <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">No Things Store Admin</span>
            </div>
            <input type="text" placeholder="Username" value={loginUser} onChange={e => setLoginUser(e.target.value)}
              className="w-full px-4 py-3 mb-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
            <input type="password" placeholder="Password" value={loginPass} onChange={e => setLoginPass(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleLogin()}
              className="w-full px-4 py-3 mb-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
            {loginError && <p className="text-red-400 text-sm mb-3">{loginError}</p>}
            <button onClick={handleLogin} className="w-full py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-xl text-white font-semibold hover:from-violet-500 hover:to-fuchsia-500 transition-all">
              <LogIn className="w-4 h-4 inline mr-2" />Log In
            </button>
            <button onClick={() => setPage('store')} className="w-full mt-3 py-2 text-gray-400 hover:text-white text-sm transition-colors">Back to Store</button>
          </div>
        </div>
      )
    }

    return (
      <div className="min-h-screen bg-gray-950 text-white">
        <nav className="bg-gray-900 border-b border-gray-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">No Things Store Admin</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setPage('store')} className="flex items-center gap-1 px-4 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-300 transition-colors">
              <Eye className="w-4 h-4" /> View Store
            </button>
            <button onClick={handleLogout} className="flex items-center gap-1 px-4 py-2 text-sm bg-red-600/20 hover:bg-red-600/30 rounded-lg text-red-400 transition-colors">
              <LogOut className="w-4 h-4" /> Logout
            </button>
          </div>
        </nav>

        <div className="flex border-b border-gray-800">
          {(['stats', 'products', 'orders', 'settings'] as const).map(tab => (
            <button key={tab} onClick={() => setAdminTab(tab)}
              className={`px-6 py-3 text-sm font-medium capitalize transition-colors ${adminTab === tab ? 'text-violet-400 border-b-2 border-violet-400' : 'text-gray-400 hover:text-white'}`}>
              {tab === 'stats' && <BarChart3 className="w-4 h-4 inline mr-1" />}
              {tab === 'products' && <Package className="w-4 h-4 inline mr-1" />}
              {tab === 'orders' && <ShoppingCart className="w-4 h-4 inline mr-1" />}
              {tab === 'settings' && <Settings className="w-4 h-4 inline mr-1" />}
              {tab}
            </button>
          ))}
        </div>

        <div className="max-w-6xl mx-auto p-6">
          {adminTab === 'stats' && stats && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-violet-500/10 rounded-xl flex items-center justify-center"><Package className="w-5 h-5 text-violet-400" /></div>
                  <span className="text-sm text-gray-400">Total Products</span>
                </div>
                <p className="text-3xl font-bold">{stats.total_products}</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-fuchsia-500/10 rounded-xl flex items-center justify-center"><ShoppingCart className="w-5 h-5 text-fuchsia-400" /></div>
                  <span className="text-sm text-gray-400">Total Orders</span>
                </div>
                <p className="text-3xl font-bold">{stats.total_orders}</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center"><DollarSign className="w-5 h-5 text-green-400" /></div>
                  <span className="text-sm text-gray-400">Revenue</span>
                </div>
                <p className="text-3xl font-bold">${stats.total_revenue.toFixed(2)}</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center"><Zap className="w-5 h-5 text-amber-400" /></div>
                  <span className="text-sm text-gray-400">Pending Orders</span>
                </div>
                <p className="text-3xl font-bold">{stats.pending_orders}</p>
              </div>
            </div>
          )}

          {adminTab === 'products' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Manage Products</h2>
                <button onClick={() => setEditProduct({ name: '', price: 0, description: '', category: '', image_url: '', badge: '', in_stock: 1, rating: 0, reviews_count: 0, original_price: null })}
                  className="flex items-center gap-1 px-4 py-2 bg-violet-600 hover:bg-violet-500 rounded-lg text-sm font-medium transition-colors">
                  <Plus className="w-4 h-4" /> Add Product
                </button>
              </div>

              {editProduct !== null && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
                  <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 w-full max-w-lg max-h-screen overflow-y-auto">
                    <h3 className="text-lg font-bold mb-4">{editProduct.id ? 'Edit Product' : 'New Product'}</h3>
                    <div className="space-y-3">
                      <input type="text" placeholder="Product Name" value={editProduct.name || ''} onChange={e => setEditProduct({ ...editProduct, name: e.target.value })}
                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                      <textarea placeholder="Description" value={editProduct.description || ''} onChange={e => setEditProduct({ ...editProduct, description: e.target.value })}
                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500 h-20 resize-none" />
                      <div className="grid grid-cols-2 gap-3">
                        <input type="number" step="0.01" placeholder="Price" value={editProduct.price || ''} onChange={e => setEditProduct({ ...editProduct, price: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                        <input type="number" step="0.01" placeholder="Original Price" value={editProduct.original_price || ''} onChange={e => setEditProduct({ ...editProduct, original_price: parseFloat(e.target.value) || null })}
                          className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                      </div>
                      <div className="space-y-2">
                        <label className="block text-sm text-gray-400 mb-1">Product Image</label>
                        <div className="flex gap-2">
                          <label className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/30 rounded-xl text-violet-300 cursor-pointer transition-colors ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
                            <Upload className="w-4 h-4" />
                            {uploading ? 'Uploading...' : 'Upload from Device'}
                            <input type="file" accept="image/*" className="hidden" onChange={e => { if (e.target.files?.[0]) handleImageUpload(e.target.files[0]) }} />
                          </label>
                        </div>
                        <input type="text" placeholder="Or paste image URL" value={editProduct.image_url || ''} onChange={e => setEditProduct({ ...editProduct, image_url: e.target.value })}
                          className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500 text-sm" />
                        {editProduct.image_url && (
                          <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-800 border border-gray-700">
                            <img src={editProduct.image_url} alt="Preview" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = imgFallback }} />
                          </div>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <input type="text" placeholder="Category" value={editProduct.category || ''} onChange={e => setEditProduct({ ...editProduct, category: e.target.value })}
                          className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                        <input type="text" placeholder="Badge (e.g. Best Seller)" value={editProduct.badge || ''} onChange={e => setEditProduct({ ...editProduct, badge: e.target.value })}
                          className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                      </div>
                    </div>
                    {productFormMsg && <p className={`mt-3 text-sm font-medium ${productFormMsgType === 'success' ? 'text-green-400' : productFormMsgType === 'error' ? 'text-red-400' : 'text-violet-400'}`}>{productFormMsg}</p>}
                    <div className="flex gap-3 mt-5">
                      <button onClick={saveProduct} disabled={uploading} className={`flex-1 py-2.5 rounded-xl text-white font-medium transition-colors flex items-center justify-center gap-1 ${uploading ? 'bg-gray-600 cursor-not-allowed opacity-50' : 'bg-violet-600 hover:bg-violet-500'}`}>
                        <Save className="w-4 h-4" /> {uploading ? 'Wait for upload...' : 'Save'}
                      </button>
                      <button onClick={() => { setEditProduct(null); setProductFormMsg('') }} className="flex-1 py-2.5 bg-gray-800 hover:bg-gray-700 rounded-xl text-gray-300 font-medium transition-colors">Cancel</button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {products.length === 0 && <p className="text-gray-400 text-center py-10">No products yet. Click &quot;Add Product&quot; to get started.</p>}
                {products.map(p => (
                  <div key={p.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center gap-4">
                    <img src={p.image_url || imgFallback} alt={p.name} onError={e => { (e.target as HTMLImageElement).src = imgFallback }}
                      className="w-16 h-16 object-cover rounded-lg flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-white truncate">{p.name}</h4>
                      <p className="text-sm text-gray-400">{p.category} &middot; ${p.price}{p.badge && ` \u00b7 ${p.badge}`}</p>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button onClick={() => setEditProduct(p)} className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-300 transition-colors"><Edit className="w-4 h-4" /></button>
                      <button onClick={() => deleteProduct(p.id)} className="p-2 bg-red-600/20 hover:bg-red-600/30 rounded-lg text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {adminTab === 'orders' && (
            <div>
              <h2 className="text-xl font-bold mb-6">Orders</h2>
              {orders.length === 0 && <p className="text-gray-400 text-center py-10">No orders yet.</p>}
              <div className="space-y-4">
                {orders.map(order => (
                  <div key={order.id} className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className="font-bold text-white">Order #{order.id}</span>
                        <span className="ml-3 text-sm text-gray-400">{new Date(order.created_at).toLocaleDateString()}</span>
                      </div>
                      <select value={order.status} onChange={e => updateOrderStatus(order.id, e.target.value)}
                        className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white focus:outline-none focus:border-violet-500">
                        <option value="pending">Pending</option>
                        <option value="paid">Paid</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                    <div className="text-sm text-gray-400 mb-2">
                      {order.customer_name || order.customer_email} &middot; <span className="text-white font-semibold">${order.total.toFixed(2)}</span>
                    </div>
                    {order.shipping_address && <p className="text-xs text-gray-500 mb-2">Ship to: {order.shipping_address}</p>}
                    <div className="border-t border-gray-800 pt-2 mt-2">
                      {order.items.map((item, i) => (
                        <p key={i} className="text-sm text-gray-400">{item.quantity}x {item.product_name} — ${(item.price * item.quantity).toFixed(2)}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {adminTab === 'settings' && (
            <div className="max-w-lg">
              <h2 className="text-xl font-bold mb-6">Settings</h2>

              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-violet-500/10 rounded-xl flex items-center justify-center">
                    <Lock className="w-5 h-5 text-violet-400" />
                  </div>
                  <h3 className="text-lg font-semibold">Change Password</h3>
                </div>
                <div className="space-y-3">
                  <input type="password" placeholder="Current Password" value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                  <input type="password" placeholder="New Password (min 6 characters)" value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                  <input type="password" placeholder="Confirm New Password" value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleChangePassword()}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
                  {passwordMsg && (
                    <p className={`text-sm ${passwordMsgType === 'success' ? 'text-green-400' : 'text-red-400'}`}>{passwordMsg}</p>
                  )}
                  <button onClick={handleChangePassword}
                    className="w-full py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-xl text-white font-semibold hover:from-violet-500 hover:to-fuchsia-500 transition-all">
                    <Save className="w-4 h-4 inline mr-2" />Update Password
                  </button>
                </div>
              </div>

              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-lg font-semibold mb-3">Quick Tips</h3>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Use a strong password with at least 6 characters</li>
                  <li>• To accept payments, set up a <a href="https://dashboard.stripe.com/register" target="_blank" rel="noopener noreferrer" className="text-violet-400 hover:text-violet-300 underline">Stripe account</a></li>
                  <li>• To get a custom domain, buy one from <a href="https://namecheap.com" target="_blank" rel="noopener noreferrer" className="text-violet-400 hover:text-violet-300 underline">Namecheap</a> or <a href="https://dash.cloudflare.com" target="_blank" rel="noopener noreferrer" className="text-violet-400 hover:text-violet-300 underline">Cloudflare</a></li>
                  <li>• To set up Google Analytics, create an account at <a href="https://analytics.google.com" target="_blank" rel="noopener noreferrer" className="text-violet-400 hover:text-violet-300 underline">analytics.google.com</a></li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  if (page === 'track') {
    return (
      <div className="min-h-screen bg-gray-950 text-white">
        <nav className="bg-gray-900 border-b border-gray-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">No Things Store</span>
          </div>
          <button onClick={() => setPage('store')} className="flex items-center gap-1 px-4 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-300 transition-colors">
            <ArrowRight className="w-4 h-4 rotate-180" /> Back to Store
          </button>
        </nav>

        <div className="max-w-2xl mx-auto p-6">
          <div className="text-center mb-8">
            <Package className="w-16 h-16 text-violet-400 mx-auto mb-4" />
            <h1 className="text-3xl font-bold mb-2">Track Your Order</h1>
            <p className="text-gray-400">Enter the email you used during checkout to see your order status</p>
          </div>

          <div className="flex gap-3 mb-6">
            <input type="email" placeholder="Enter your email address" value={trackEmail} onChange={e => { setTrackEmail(e.target.value); setTrackMsg('') }}
              onKeyDown={e => e.key === 'Enter' && handleTrackOrders()}
              className="flex-1 px-5 py-3 bg-gray-900 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-violet-500" />
            <button onClick={handleTrackOrders} disabled={trackLoading}
              className="px-6 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 rounded-xl text-white font-semibold transition-all disabled:opacity-50">
              {trackLoading ? 'Searching...' : 'Track'}
            </button>
          </div>

          {trackMsg && <p className="text-center text-gray-400 mb-6">{trackMsg}</p>}

          {trackedOrders.length > 0 && (
            <div className="space-y-4">
              {trackedOrders.map(order => (
                <div key={order.id} className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-400">Order #{order.id}</p>
                      <p className="text-xs text-gray-500">{new Date(order.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${statusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="space-y-2 mb-4">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-sm">
                        <span className="text-gray-300">{item.product_name} x{item.quantity}</span>
                        <span className="text-gray-400">${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-gray-800 pt-3 flex items-center justify-between">
                    <span className="text-sm text-gray-400">Total</span>
                    <span className="text-lg font-bold text-white">${order.total.toFixed(2)}</span>
                  </div>
                  {order.status === 'pending' && (
                    <p className="mt-3 text-xs text-yellow-400">Your order is being processed. We&apos;ll update the status soon.</p>
                  )}
                  {order.status === 'paid' && (
                    <p className="mt-3 text-xs text-green-400">Payment confirmed! Your order will be shipped soon.</p>
                  )}
                  {order.status === 'shipped' && (
                    <p className="mt-3 text-xs text-blue-400">Your order is on its way! You&apos;ll receive it shortly.</p>
                  )}
                  {order.status === 'delivered' && (
                    <p className="mt-3 text-xs text-emerald-400">Your order has been delivered. Thank you for shopping with us!</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    )
  }

  const categoryIcons: Record<string, string> = {
    'All': '🛍️',
    'Audio': '🎧',
    'Wearables': '⌚',
    'Cameras': '📷',
    'Gaming': '🎮',
    'Accessories': '🔌',
    'Smart Home': '🏠',
    'Mobiles': '📱',
    'Laptops': '💻',
  }

  return (
    <div className="min-h-screen bg-white text-gray-900 pb-16">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-50 bg-gradient-to-r from-violet-600 to-fuchsia-600 shadow-lg">
        <div className="flex items-center gap-3 px-3 py-2.5">
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-bold text-white hidden sm:block">No Things Store</span>
          </div>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input type="text" placeholder="Search No Things Store" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 bg-white rounded-lg text-gray-900 placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 shadow-inner" />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Scrollable Category Row */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="flex overflow-x-auto gap-1 px-2 py-3 scrollbar-hide">
          {categories.map(cat => (
            <button key={cat} onClick={() => setSelectedCategory(cat)}
              className={`flex flex-col items-center gap-1 px-3 py-1 min-w-16 flex-shrink-0 rounded-lg transition-all ${selectedCategory === cat ? "bg-violet-50 text-violet-700" : "text-gray-600 hover:bg-gray-50"}`}>
              <span className="text-2xl">{categoryIcons[cat] || '📦'}</span>
              <span className="text-xs font-medium whitespace-nowrap">{cat}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Banner / Promo Carousel */}
      <div className="overflow-x-auto scrollbar-hide">
        <div className="flex gap-3 px-3 py-4 min-w-max">
          <div className="w-80 sm:w-96 flex-shrink-0 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-violet-500/20 rounded-full blur-2xl" />
            <div className="relative">
              <p className="text-violet-400 text-xs font-semibold mb-1 uppercase tracking-wide">Spring Sale</p>
              <h3 className="text-white text-xl font-bold mb-1">Up to 40% Off</h3>
              <p className="text-gray-400 text-sm mb-3">Premium electronics &amp; gadgets</p>
              <a href="#products" className="inline-flex items-center gap-1 px-4 py-1.5 bg-violet-600 text-white text-xs font-semibold rounded-full hover:bg-violet-500 transition-colors">
                Shop Now <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
          <div className="w-80 sm:w-96 flex-shrink-0 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-xl" />
            <div className="relative">
              <p className="text-amber-900 text-xs font-semibold mb-1 uppercase tracking-wide">Free Shipping</p>
              <h3 className="text-white text-xl font-bold mb-1">Orders Over $50</h3>
              <p className="text-amber-100 text-sm mb-3">Fast &amp; reliable delivery</p>
              <a href="#products" className="inline-flex items-center gap-1 px-4 py-1.5 bg-white text-amber-700 text-xs font-semibold rounded-full hover:bg-amber-50 transition-colors">
                Browse <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
          <div className="w-80 sm:w-96 flex-shrink-0 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-xl" />
            <div className="relative">
              <p className="text-emerald-200 text-xs font-semibold mb-1 uppercase tracking-wide">Order via</p>
              <h3 className="text-white text-xl font-bold mb-1">Call or WhatsApp</h3>
              <p className="text-emerald-100 text-sm mb-3">Easy ordering by phone</p>
              <a href="tel:+917204158549" className="inline-flex items-center gap-1 px-4 py-1.5 bg-white text-emerald-700 text-xs font-semibold rounded-full hover:bg-emerald-50 transition-colors">
                <Phone className="w-3.5 h-3.5" /> Call Now
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Info Strip */}
      <div className="flex overflow-x-auto gap-3 px-3 py-3 bg-gray-50 border-b border-gray-200 scrollbar-hide">
        <div className="flex items-center gap-2 bg-white rounded-xl px-4 py-2.5 border border-gray-200 flex-shrink-0 shadow-sm">
          <Truck className="w-5 h-5 text-violet-600" />
          <div><p className="text-xs font-semibold text-gray-900">Free Shipping</p><p className="text-xs text-gray-400">Orders $50+</p></div>
        </div>
        <div className="flex items-center gap-2 bg-white rounded-xl px-4 py-2.5 border border-gray-200 flex-shrink-0 shadow-sm">
          <Shield className="w-5 h-5 text-violet-600" />
          <div><p className="text-xs font-semibold text-gray-900">2 Year Warranty</p><p className="text-xs text-gray-400">All products</p></div>
        </div>
        <div className="flex items-center gap-2 bg-white rounded-xl px-4 py-2.5 border border-gray-200 flex-shrink-0 shadow-sm">
          <Zap className="w-5 h-5 text-violet-600" />
          <div><p className="text-xs font-semibold text-gray-900">24/7 Support</p><p className="text-xs text-gray-400">Always here</p></div>
        </div>
      </div>

      {/* Products Section */}
      <section id="products" className="px-3 py-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-900">
            {searchQuery ? `Results for "${searchQuery}"` : selectedCategory !== 'All' ? selectedCategory : 'Featured Products'}
          </h2>
          <span className="text-sm text-gray-500">{products.length} items</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {products.map(product => (
            <div key={product.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-200 group">
              <div className="relative aspect-square bg-gray-50 overflow-hidden">
                <img src={product.image_url || imgFallback} alt={product.name}
                  onError={e => { (e.target as HTMLImageElement).src = imgFallback }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                {product.badge && <span className="absolute top-2 left-2 px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded">{product.badge}</span>}
                <button onClick={() => toggleWishlist(product.id)} className="absolute top-2 right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors">
                  <Heart className={`w-4 h-4 ${wishlist.includes(product.id) ? "text-red-500 fill-red-500" : "text-gray-400"}`} />
                </button>
              </div>
              <div className="p-3">
                <p className="text-xs text-gray-500 mb-0.5">{product.category}</p>
                <h3 className="text-sm font-medium text-gray-900 mb-1.5 line-clamp-2 leading-tight">{product.name}</h3>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span className="text-xs text-gray-700">{product.rating}</span>
                  <span className="text-xs text-gray-400">({product.reviews_count.toLocaleString()})</span>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg font-bold text-gray-900">₹{product.price}</span>
                  {product.original_price && <span className="text-xs text-gray-400 line-through">₹{product.original_price}</span>}
                </div>
                <button onClick={() => addToCart(product)}
                  className="w-full py-2 bg-amber-400 hover:bg-amber-500 rounded-lg text-sm font-semibold text-gray-900 transition-colors flex items-center justify-center gap-1">
                  <Plus className="w-4 h-4" /> Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No products found. Check back soon!</p>
          </div>
        )}
      </section>

      {/* Deals Banner */}
      <section id="deals" className="px-3 py-4">
        <div className="bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-2xl p-6 md:p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl" />
          <div className="relative">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">Spring Sale is Live!</h2>
            <p className="text-violet-100 text-sm mb-4 max-w-md">Get up to 40% off on selected items. Limited time offer.</p>
            <a href="#products" className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-violet-700 font-semibold rounded-full text-sm hover:bg-violet-50 transition-colors shadow-lg">
              Shop the Sale <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="px-3 py-4">
        <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6 text-center">
          <h2 className="text-xl font-bold text-gray-900 mb-2">Stay in the Loop</h2>
          <p className="text-gray-500 text-sm mb-4">Get exclusive deals, new arrivals, and tech tips.</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 max-w-md mx-auto">
            <input type="email" placeholder="Enter your email" value={subscribeEmail} onChange={e => { setSubscribeEmail(e.target.value); setSubscribeMsg('') }}
              onKeyDown={e => e.key === 'Enter' && handleSubscribe()}
              className="w-full px-4 py-2.5 bg-white border border-gray-300 rounded-lg text-gray-900 placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500" />
            <button onClick={handleSubscribe} className="w-full sm:w-auto px-6 py-2.5 bg-violet-600 hover:bg-violet-700 rounded-lg text-white font-semibold text-sm transition-colors whitespace-nowrap">Subscribe</button>
          </div>
          {subscribeMsg && <p className="mt-3 text-sm text-green-600 font-medium">{subscribeMsg}</p>}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 border-t border-gray-200 mt-4 pb-20">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-lg flex items-center justify-center"><Zap className="w-4 h-4 text-white" /></div>
                <span className="text-base font-bold text-gray-900">No Things Store</span>
              </div>
              <p className="text-gray-500 text-xs">Your one-stop shop for premium tech products.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 text-sm mb-3">Shop</h4>
              <ul className="space-y-1.5">
                <li><a href="#products" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">All Products</a></li>
                <li><a href="#deals" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">Deals</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 text-sm mb-3">Support</h4>
              <ul className="space-y-1.5">
                <li><a href="tel:+917204158549" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">+91 72041 58549</a></li>
                <li><a href="tel:+919980201878" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">+91 99802 01878</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 text-sm mb-3">Company</h4>
              <ul className="space-y-1.5">
                <li><a href="#" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">About Us</a></li>
                <li><a href="#" className="text-xs text-gray-500 hover:text-gray-900 transition-colors">Privacy Policy</a></li>
                <li><button onClick={() => setPage('admin')} className="text-xs text-gray-300 hover:text-gray-400 transition-colors mt-2">Admin</button></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-6 pt-4 text-center">
            <p className="text-xs text-gray-400">&copy; 2026 No Things Store. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around py-2 max-w-lg mx-auto">
          <a href="#" className="flex flex-col items-center gap-0.5 px-3 py-1 text-violet-600">
            <Zap className="w-5 h-5" />
            <span className="text-xs font-medium">Home</span>
          </a>
          <button onClick={() => setPage('track')} className="flex flex-col items-center gap-0.5 px-3 py-1 text-gray-500 hover:text-violet-600 transition-colors">
            <Package className="w-5 h-5" />
            <span className="text-xs font-medium">Track</span>
          </button>
          <button onClick={() => setIsCartOpen(true)} className="flex flex-col items-center gap-0.5 px-3 py-1 text-gray-500 hover:text-violet-600 transition-colors relative">
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 right-0 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center font-bold">{cartCount}</span>
            )}
            <span className="text-xs font-medium">Cart</span>
          </button>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="flex flex-col items-center gap-0.5 px-3 py-1 text-gray-500 hover:text-violet-600 transition-colors">
            <Menu className="w-5 h-5" />
            <span className="text-xs font-medium">Menu</span>
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-72 bg-white shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <span className="text-white font-bold">Menu</span>
              <button onClick={() => setIsMobileMenuOpen(false)} className="text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="flex-1 overflow-y-auto py-2">
              <a href="#products" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors">
                <ShoppingCart className="w-5 h-5 text-gray-400" />
                <span className="font-medium">All Products</span>
              </a>
              <a href="#deals" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors">
                <Zap className="w-5 h-5 text-gray-400" />
                <span className="font-medium">Deals</span>
              </a>
              <button onClick={() => { setPage('track'); setIsMobileMenuOpen(false) }} className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors w-full text-left">
                <Package className="w-5 h-5 text-gray-400" />
                <span className="font-medium">Track Order</span>
              </button>
              <div className="border-t border-gray-200 mt-2 pt-2">
                <a href="tel:+917204158549" className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors">
                  <Phone className="w-5 h-5 text-green-500" />
                  <span className="font-medium">Call: +91 72041 58549</span>
                </a>
                <a href="tel:+919980201878" className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors">
                  <Phone className="w-5 h-5 text-green-500" />
                  <span className="font-medium">Call: +91 99802 01878</span>
                </a>
                <a href="https://wa.me/917204158549" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-5 py-3.5 text-gray-700 hover:bg-gray-50 transition-colors">
                  <MessageCircle className="w-5 h-5 text-green-500" />
                  <span className="font-medium">WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {isCartOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { setIsCartOpen(false); setShowCheckoutForm(false) }} />
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-gray-900 border-l border-gray-800 shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <h2 className="text-xl font-bold flex items-center gap-2"><ShoppingCart className="w-5 h-5" /> Cart ({cartCount})</h2>
              <button onClick={() => { setIsCartOpen(false); setShowCheckoutForm(false) }} className="p-2 text-gray-400 hover:text-white transition-colors"><X className="w-6 h-6" /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center py-16">
                  <ShoppingCart className="w-16 h-16 text-gray-700 mx-auto mb-4" />
                  <p className="text-gray-400">Your cart is empty</p>
                  <button onClick={() => setIsCartOpen(false)} className="mt-4 text-violet-400 hover:text-violet-300 font-medium text-sm">Continue Shopping</button>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex gap-4 bg-gray-800/50 rounded-xl p-4">
                    <img src={item.image_url || imgFallback} alt={item.name} onError={e => { (e.target as HTMLImageElement).src = imgFallback }}
                      className="w-20 h-20 object-cover rounded-lg flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-white truncate">{item.name}</h4>
                      <p className="text-violet-400 font-semibold mt-1">₹{item.price}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <button onClick={() => updateQuantity(item.id, -1)} className="w-7 h-7 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"><Minus className="w-3 h-3" /></button>
                        <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="w-7 h-7 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"><Plus className="w-3 h-3" /></button>
                        <button onClick={() => removeFromCart(item.id)} className="ml-auto p-1.5 text-gray-500 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="border-t border-gray-800 p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Subtotal</span>
                  <span className="text-xl font-bold text-white">₹{cartTotal.toFixed(2)}</span>
                </div>

                {showCheckoutForm ? (
                  <div className="space-y-3">
                    <p className="text-sm text-gray-400 text-center">Choose how you'd like to order:</p>
                    <a href="tel:+917204158549"
                      className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-full text-white font-semibold transition-all shadow-lg shadow-green-500/25 flex items-center justify-center gap-2">
                      <Phone className="w-5 h-5" /> Call: +91 72041 58549
                    </a>
                    <a href="tel:+919980201878"
                      className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-full text-white font-semibold transition-all shadow-lg shadow-green-500/25 flex items-center justify-center gap-2">
                      <Phone className="w-5 h-5" /> Call: +91 99802 01878
                    </a>
                    <a href={`https://wa.me/917204158549?text=${encodeURIComponent(`                    Hi! I'd like to place an order from No Things Store.\n\nItems:\n${cart.map(item => `• ${item.name} x${item.quantity} - ₹${(item.price * item.quantity).toFixed(2)}`).join('\n')}\n\nTotal: ₹${cartTotal.toFixed(2)}`)}`}
                                          target="_blank" rel="noopener noreferrer"
                                          className="w-full py-3 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-400 hover:to-teal-400 rounded-full text-white font-semibold transition-all shadow-lg shadow-green-500/25 flex items-center justify-center gap-2">
                                          <MessageCircle className="w-5 h-5" /> WhatsApp: +91 72041 58549
                                        </a>
                                        <a href={`https://wa.me/919980201878?text=${encodeURIComponent(`Hi! I'd like to place an order from No Things Store.\n\nItems:\n${cart.map(item => `• ${item.name} x${item.quantity} - ₹${(item.price * item.quantity).toFixed(2)}`).join('\n')}\n\nTotal: ₹${cartTotal.toFixed(2)}`)}`}
                      target="_blank" rel="noopener noreferrer"
                      className="w-full py-3 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-400 hover:to-teal-400 rounded-full text-white font-semibold transition-all shadow-lg shadow-green-500/25 flex items-center justify-center gap-2">
                      <MessageCircle className="w-5 h-5" /> WhatsApp: +91 99802 01878
                    </a>
                    <div className="flex items-center gap-3 py-1">
                      <div className="flex-1 border-t border-gray-700" />
                      <span className="text-xs text-gray-500">or place order online</span>
                      <div className="flex-1 border-t border-gray-700" />
                    </div>
                    <input type="email" placeholder="Email *" value={checkoutEmail} onChange={e => setCheckoutEmail(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 text-sm focus:outline-none focus:border-violet-500" />
                    <input type="text" placeholder="Full Name *" value={checkoutName} onChange={e => setCheckoutName(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 text-sm focus:outline-none focus:border-violet-500" />
                    <input type="text" placeholder="Shipping Address *" value={checkoutAddress} onChange={e => setCheckoutAddress(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-400 text-sm focus:outline-none focus:border-violet-500" />
                    {checkoutError && <p className="text-red-400 text-sm">{checkoutError}</p>}
                    <div className="bg-gray-800 border border-violet-500/30 rounded-xl p-3 space-y-2">
                      <p className="text-xs text-violet-400 font-semibold text-center">Pay via UPI</p>
                      <a href={`upi://pay?pa=9980201878@sbi&pn=No Things Store&am=${cartTotal.toFixed(2)}&cu=INR&tn=Order from No Things Store`}
                        className="w-full py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 rounded-lg text-white font-semibold transition-all shadow-lg shadow-violet-500/25 flex items-center justify-center gap-2 text-sm">
                        💳 Pay ₹{cartTotal.toFixed(2)} to 9980201878@sbi
                      </a>
                      <a href={`upi://pay?pa=7204158549@fam&pn=No Things Store&am=${cartTotal.toFixed(2)}&cu=INR&tn=Order from No Things Store`}
                        className="w-full py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 rounded-lg text-white font-semibold transition-all shadow-lg shadow-violet-500/25 flex items-center justify-center gap-2 text-sm">
                        💳 Pay ₹{cartTotal.toFixed(2)} to 7204158549@fam
                      </a>
                      <p className="text-xs text-gray-500 text-center">Opens PhonePe / GPay / Paytm on your phone</p>
                    </div>
                    <button onClick={() => handleCheckout('upi')} disabled={checkoutLoading}
                      className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-full text-white font-semibold transition-all shadow-lg shadow-green-500/25 disabled:opacity-50 flex items-center justify-center gap-2">
                      {checkoutLoading ? 'Processing...' : '✅ I have paid via UPI — Place Order'}
                    </button>
                    <div className="flex items-center gap-3 py-1">
                      <div className="flex-1 border-t border-gray-700" />
                      <span className="text-xs text-gray-500">or</span>
                      <div className="flex-1 border-t border-gray-700" />
                    </div>
                    <button onClick={() => handleCheckout('cod')} disabled={checkoutLoading}
                      className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 rounded-full text-white font-semibold transition-all shadow-lg shadow-amber-500/25 disabled:opacity-50 flex items-center justify-center gap-2">
                      {checkoutLoading ? 'Processing...' : '📦 Cash on Delivery'}
                    </button>
                  </div>
                ) : (
                  <button onClick={() => setShowCheckoutForm(true)}
                    className="w-full py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 rounded-full text-white font-semibold transition-all shadow-lg shadow-violet-500/25">
                    Checkout
                  </button>
                )}
                <button onClick={() => { setIsCartOpen(false); setShowCheckoutForm(false) }}
                  className="w-full py-3 bg-gray-800 hover:bg-gray-700 rounded-full text-gray-300 font-medium transition-colors">Continue Shopping</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default App
